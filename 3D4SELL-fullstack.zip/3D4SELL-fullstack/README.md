# 3D4SELL full-stack marketplace starter

Includes customer registration/login, admin product uploads, SQLite catalog/orders, Paystack NGN checkout initialization, server-side transaction verification, signed webhook validation, and paid-order-only private file downloads.

## Start locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a long random `SESSION_SECRET`, use `ADMIN_EMAIL=brokengee64@gmail.com` (or change it if needed), and set a unique strong `ADMIN_PASSWORD`.
4. Add your Paystack **test** secret key as `PAYSTACK_SECRET_KEY`.
5. Set `PUBLIC_BASE_URL=http://localhost:3000`.
6. Run `npm install`, then `npm start`; open http://localhost:3000.

An initial admin is created at startup if the configured email does not exist. Sign in with those admin credentials to upload products.

## Paystack
Configure the webhook URL as `https://YOUR-DOMAIN/api/paystack/webhook`; set `PUBLIC_BASE_URL` to your HTTPS domain. Keep secret keys on the server only. Test with Paystack test credentials before switching to live credentials. Payment amounts are calculated from server-side product prices.

## Production checklist
This is a starter, not a security-audited production service. Before launch, deploy behind HTTPS; use a strong secret and persistent private file storage; back up the database; configure proxy/security headers; add CSRF/origin protection, email verification, password reset, upload malware scanning/content validation, download limits/expiry, customer support, terms/privacy/refund/licensing policies, monitoring and tax/compliance review. Admin product upload accepts GLB, GLTF, FBX, OBJ, BLEND and ZIP up to 150 MB. Creator self-service and per-product interactive previews are not included yet.

No live payment can run until you configure your own Paystack account and credentials.


## Recommended hosting: Railway
1. Create a Railway project and deploy this Node.js app from a GitHub repository.
2. Add a persistent Volume and mount it at `/data`. The database, session store and private 3D uploads must live on this volume so they survive redeploys.
3. Add these Railway Variables: `DB_PATH=/data/3d4sell.sqlite`, `UPLOAD_DIR=/data/private_uploads`, `SESSION_DB_DIR=/data`, `NODE_ENV=production`, `SESSION_SECRET` (a long random value), `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `PAYSTACK_SECRET_KEY`, and `PUBLIC_BASE_URL` (your final HTTPS domain).
4. Generate or connect a domain with HTTPS. Set `PUBLIC_BASE_URL` to that exact origin.
5. In Paystack Dashboard → Settings → API Keys & Webhooks, use test credentials first and set webhook URL to `https://YOUR-DOMAIN/api/paystack/webhook`. Never paste secret keys into frontend code, GitHub, or a public chat.
6. Complete test purchases and verify that paid orders unlock downloads. Only then switch to live Paystack credentials.

Railway is the recommended beginner-friendly managed host for this Node/Express app. A persistent volume is essential because this starter stores its SQLite database, sessions and uploaded model files on disk. Hosting charges and volume usage depend on current plan and traffic.
